﻿namespace Birk.Client.Bestilling.Models.Dtos
{
    public class BestillingTypeDto : ExtendedBaseDto
    {
        public int Pk { get; set; }
    }
}
