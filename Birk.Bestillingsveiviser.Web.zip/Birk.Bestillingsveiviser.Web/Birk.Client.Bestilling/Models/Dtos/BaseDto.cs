﻿namespace Birk.Client.Bestilling.Models.Dtos
{
    public class BaseDto
    {
        public string? RegAv { get; set; }
        public DateTime? RegDato { get; set; }
        public string? EndretAv { get; set; }
        public DateTime? EndretDato { get; set; }
    }
}
