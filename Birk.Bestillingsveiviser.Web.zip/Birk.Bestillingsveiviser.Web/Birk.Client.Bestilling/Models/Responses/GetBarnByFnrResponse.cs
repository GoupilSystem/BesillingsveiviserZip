﻿using Birk.Client.Bestilling.Models.Dtos;

namespace Birk.Client.Bestilling.Models.Responses
{
    public class GetBarnByFnrResponse
    {
        public BarnOgPersonDto barnOgPersonDto { get; set; }
    }
}
