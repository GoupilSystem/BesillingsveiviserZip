﻿namespace Birk.Client.Bestilling.Models.Responses
{
    public class EditBestillingItemResponse
    {
        public BestillingItem BestillingItem { get; set; } = new();
    }
}