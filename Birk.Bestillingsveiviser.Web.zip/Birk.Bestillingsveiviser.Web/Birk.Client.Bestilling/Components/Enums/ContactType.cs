﻿namespace Birk.Client.Bestilling.Components.Enums
{
    public enum ContactType
    {
        Person,
        Leder
    }
}
