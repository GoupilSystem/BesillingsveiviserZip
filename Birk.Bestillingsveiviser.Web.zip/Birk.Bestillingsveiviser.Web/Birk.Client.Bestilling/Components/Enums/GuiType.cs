﻿namespace Birk.Client.Bestilling.Components.Enums
{
    public enum GuiType
    {
        Label,
        Dropdown,
        Title,
        Input,
        Button,
        CheckBox,
        TextArea
    }
}
